# 🎵 LRC Bulk Finder v2.1.15 — Offline-Only Edition (Public Beta)

**Created by Dimitris L.**

### New in v2.1.15
- **Option 4 — OFFLINE LRCLIB ONLY:** Scan any MP3 folder, including subfolders, without an existing catch-up queue and without lyrics-provider network requests.
- **Connect existing SQLite database:** Reuse a previously extracted LRCLIB database without downloading or moving it. `CONNECT_EXISTING_LRCLIB_DATABASE.cmd` stores a tiny local path configuration.
- **Separate offline reports:** Detailed result and review CSVs for option 4.
- Existing options **1 (SEARCH), 2 (PROMOTE), 3 (CATCH-UP)** remain available.

### Quick start
1. Extract the Windows ZIP.
2. If you already have an extracted LRCLIB database, run `CONNECT_EXISTING_LRCLIB_DATABASE.cmd` and select your `.sqlite3` file.
3. Run `START_HERE.cmd` and choose `4` for offline-only folder scanning, or `1` for offline-first with online source fallback.
4. Test 20 songs before scanning entire libraries (`A`).

### Included documentation
Download the accompanying **17-page English PDF user manual** for a walkthrough of all nine Windows CMD/BAT launchers, each startup prompt, storage requirements, safety, reporting, example workflows, and release history.

### Important
- Windows 10/11 and Python 3.10+ required.
- The LRCLIB SQLite snapshot is **not bundled**; downloading it is optional and can require hundreds of gigabytes of storage.
- Review `.candidate.lrc` matches before promotion; strict version/duration checks remain in place.
- This is a **Public Beta**: offline fixture tests do not guarantee live provider availability or every Windows configuration.

### Recommended GitHub topics
`lyrics` · `lrc` · `synchronized-lyrics` · `windows` · `python` · `music-library` · `lrclib` · `sqlite` · `offline-first` · `greeklish` · `mp3` · `command-line-tool`
