# Changelog

All dates refer to development notes; **v2.1.15 remains a Public Beta**.

## v2.1.15 — Offline-only folder search
- New main menu **4 — OFFLINE LRCLIB ONLY**, usable for any chosen directory with no catch-up queue.
- Added `CONNECT_EXISTING_LRCLIB_DATABASE.cmd` to link a previously extracted official SQLite snapshot without copying or redownloading it.
- Added versioned offline-only result and candidate-review CSVs; existing search reports and queues remain separate.
- Preserved strict track/version/duration matching, LIVE exclusions, and protection of existing MP3s and `.lrc` files.

## v2.1.14 — Safe cleanup
- Added `CLEANUP_LRCLIB_DATABASE.cmd` with choices for archive-only, extracted-database-only, both, or cancel.
- Added typed confirmation and post-install storage reporting.

## v2.1.13 — Snapshot discovery repair
- Switched the automatic installer to the structured LRCLIB dump catalog when available, with a fallback and validated filenames.

## v2.1.12 — Auto installer
- Added optional official LRCLIB database discovery/download, resumable download handling and validation; the dump is not bundled.

## v2.1.11 — Local SQLite support
- Added local LRCLIB lookup before online searches and safer recovery from repeated HTTP 503 errors.

## v2.1.10 — Coverage and recovery
- Added first-attempt provider coverage reporting and improved handling of temporary provider failures.

## v2.1.9 — LRCLIB stable beta
- Improved 503/429 handling and request spacing; introduced optional exact lookup and a persistent LRCLIB catch-up queue.

## v2.1.8 — Candidate workflow
- Added startup actions and `.candidate.lrc` sidecar review and explicit promotion.

## v2.1.7 — LRCLIB priority
- Prioritized LRCLIB searching and improved overload handling.

## v2.1.6 — Diagnostics
- Added provider request status and error visibility, skip reasons and HTTP diagnostics.

## v2.1.5 — Metadata improvements
- Made MusicBrainz metadata lookup available to both international and Greek collections and configured LRCLIB project identification.

## v2.1.4 — Public beta reliability
- History/review reporting changes, safer cooldown handling, and public beta packaging.

## v2.1.3–v2.1.2
- Tightened automatic artist/title/version/duration verification; improved public-ready packaging and Greek alternatives.

## v1.x–v2.1.1
- Initial synchronized lyric search, Greeklish support, multi-source searching, and optional local Greek G2G model.
