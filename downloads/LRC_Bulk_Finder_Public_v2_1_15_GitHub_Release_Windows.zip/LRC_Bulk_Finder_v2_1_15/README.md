# LRC Bulk Finder

**Windows command-line synchronized lyrics finder · Public Beta · v2.1.15**  
Created by **Dimitris L.**

LRC Bulk Finder searches MP3 collections for timestamped `.lrc` files. It supports an optional **offline LRCLIB SQLite snapshot**, online lyrics providers, Greek/Greeklish filename handling, and strict verification intended to reduce incorrect remix/version matches.

> **Beta notice:** No provider, offline snapshot, or metadata search guarantees synchronized lyrics for every recording. This project does not distribute the LRCLIB database or any song lyrics.

## Download and start

Download the **Windows ZIP** and the **User Manual PDF** from the matching version's [Releases](https://github.com/DimitrisLai/LRC-Bulk-Finder/releases) page. Extract the ZIP before running anything. Requires Windows 10/11 and Python 3.10+.

Double-click **`START_HERE.cmd`** and choose:

| Menu | Action | Network |
|---|---|---|
| `1` | SEARCH for synchronized lyrics; offline LRCLIB first if configured, then available online providers | Yes, for online providers |
| `2` | PROMOTE reviewed `.candidate.lrc` sidecars | No |
| `3` | LRCLIB-only catch-up from a previously created incomplete-search queue | Optional online fallback |
| `4` | **OFFLINE LRCLIB ONLY** — scan any selected MP3 folder, no catch-up queue needed | No search requests |

**For a large folder and an already-downloaded database:** Run `CONNECT_EXISTING_LRCLIB_DATABASE.cmd` once to point the program at your extracted `.sqlite3` file. It writes only a tiny `LRCLIB_LOCAL_DB.txt` configuration. It does **not** download or copy the multi-hundred-gigabyte database. Then run `START_HERE.cmd`, choose **4**, select a folder, choose `20` for a trial or `A` for all eligible songs, and confirm `Y`.

## Every Windows launcher

| Launcher | Purpose |
|---|---|
| `START_HERE.cmd` | Recommended main entry point, menu 1–4 |
| `CONNECT_EXISTING_LRCLIB_DATABASE.cmd` | Reuse an already extracted offline SQLite database |
| `SETUP_LRCLIB_DATABASE.cmd` | Optional official database snapshot download, extraction, and validation |
| `SETUP_LRCLIB_DATABASE_FROM_FILE.cmd` | Set up from a previously downloaded `.sqlite3` or `.sqlite3.gz` file |
| `CLEANUP_LRCLIB_DATABASE.cmd` | Safely delete an auto-installed compressed snapshot, the extracted DB, or both — explicit confirmation required |
| `SETUP_GREEK_AI.cmd` | Optional Greeklish-to-Greek local G2G AI installation |
| `Run_Diagnostics.cmd` | Python/dependency troubleshooting report |
| `Run_LRC_Finder.cmd` | Internal runner invoked by START_HERE |
| `Start_LRC_Finder.bat` | Compatibility launcher for START_HERE |

## Safety and matching

- Keeps the original MP3 audio and ID3 artist/title tags unchanged.
- Skips songs with an existing `.lrc` and excludes LIVE recordings.
- Auto-saves synchronized lyrics only after verifying artist, title, recording version, and close duration (≤3 seconds).
- Saves uncertain candidates as `.candidate.lrc` for **manual review**. Do not bulk-promote without checking them.
- Retries only real network timeouts for the same track/provider; access restrictions, HTTP 429 and HTTP 503 are not treated as timeouts.
- Option 4 searches the installed local SQLite snapshot without querying providers or MusicBrainz.

## Using offline LRCLIB

The full LRCLIB database is not included and can be very large. Download it separately through `SETUP_LRCLIB_DATABASE.cmd`, or **connect an existing extracted database** without redownloading it. The project has observed an official October 2026 snapshot extracting to roughly 243.5 GiB; future sizes can differ.

After confirming a successful installation, `CLEANUP_LRCLIB_DATABASE.cmd` offers option `1` to delete **only** the compressed archive and preserve offline searching. Deleting the extracted `.sqlite3` database disables offline searching.

## Greek music

Select Greek mode `Y` for Greek/Greeklish music. If the local G2G model is installed, enable it for additional name alternatives. MusicBrainz Picard is **not required**. MusicBrainz metadata search itself is optional in menu 1.

## Documentation

The release PDF **`LRC_Bulk_Finder_v2_1_15_Complete_User_Manual_EN.pdf`** includes every CMD/BAT launcher, prompt choice and default, examples, provider diagnostics, safe candidate promotion, database cleanup and version history.

See [`CHANGELOG.md`](CHANGELOG.md) for updates and [`SOURCES_AND_CREDITS.txt`](SOURCES_AND_CREDITS.txt) for third-party services and tools.

## Third-party rights and license

The original source-code license requires a deliberate choice by the project owner; do not assume the presence of a public GitHub repository authorizes unrestricted reuse. Third-party packages and provider/database content have their own licenses and terms. Review [`PUBLICATION_AND_LICENSE_NOTES.txt`](PUBLICATION_AND_LICENSE_NOTES.txt) before adopting a project license or republishing database contents.

## Issues

Use [GitHub Issues](https://github.com/DimitrisLai/LRC-Bulk-Finder/issues) to report reproducible problems. Include version, selected menu option, sanitized diagnostics, and Python/Windows versions. Do **not** upload private music libraries or copyrighted lyrics.
